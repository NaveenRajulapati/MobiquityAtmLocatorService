package com.example.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.AtmDetails;
import com.example.service.RetrieveAtmsService;

@RestController
@RequestMapping("/api/atms")
public class AtmLocatorController {

    @Autowired
    private RetrieveAtmsService retrieveAtmsService;

    @GetMapping("/all")
    public List<AtmDetails> getAllAtms() {
        return retrieveAtmsService.getAllAtms();
    }

    @GetMapping("/")
    public List<AtmDetails> getAllAtmsByCity(@RequestParam(value = "cityName") String cityName) {
        return retrieveAtmsService.getAllAtmsByCity(cityName);
    }

}
