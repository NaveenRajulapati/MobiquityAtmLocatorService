package com.example.service;

import com.example.model.AtmDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import static com.example.datafactory.AtmDetailsTestDataFactory.getAtmDetailsWithGivenCity;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RetrieveAtmsServiceTest {

    @InjectMocks
    private RetrieveAtmsService retrieveAtmsService;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper objectMapper;

    private static final String restUrl = "http://localhost:15195//test";

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(retrieveAtmsService, "restUrl", restUrl);
    }


    @Test
    public void shouldRetrieveAllTheAtmDetails() throws JsonProcessingException {
        //Given
        List<AtmDetails> expectedAtmDetails = Arrays.asList(getAtmDetailsWithGivenCity("city1"),
                getAtmDetailsWithGivenCity("city2"));
        when(restTemplate.exchange(restUrl, HttpMethod.GET, null, String.class))
                .thenReturn(ResponseEntity.ok().body(getJsonStringResponse()));
        when(objectMapper.readValue(anyString(), any(TypeReference.class))).thenReturn(expectedAtmDetails);

        //When
        List<AtmDetails> actualAtmDetails = retrieveAtmsService.getAllAtms();

        //Then
        assertEquals(expectedAtmDetails, actualAtmDetails);
    }

    @Test
    public void shouldRetrieveAtmDetailsByCity() throws JsonProcessingException {
        //Given
        List<AtmDetails> expectedAtmDetails = Arrays.asList(getAtmDetailsWithGivenCity("city1"),
                getAtmDetailsWithGivenCity("city1"));
        when(restTemplate.exchange(restUrl, HttpMethod.GET, null, String.class))
                .thenReturn(ResponseEntity.ok().body(getJsonStringResponse()));
        when(objectMapper.readValue(anyString(), any(TypeReference.class))).thenReturn(expectedAtmDetails);

        //When
        List<AtmDetails> actualAtmDetails = retrieveAtmsService.getAllAtms();

        //Then
        assertEquals(expectedAtmDetails, actualAtmDetails);
    }


    private String getJsonStringResponse() {
        String jsonResponse = ")\n" +
                "]\n" +
                "}',\n" +
                "[\n" +
                "{\n" +
                "\"address\": {\n" +
                "    \"street\": \"Nieuwe Binnenweg\",\n" +
                "    \"housenumber\": \"34A\",\n" +
                "    \"postalcode\": \"3015 BA\",\n" +
                "    \"city\": \"Rotterdam\",\n" +
                "    \"geoLocation\": {\n" +
                "        \"lat\": \"51.916214\",\n" +
                "        \"lng\": \"4.469937\"\n" +
                "    }\n" +
                "},\n" +
                "\"distance\": 0,\n" +
                "\"functionality\": \"Geld storten en opnemen\",\n" +
                "\"type\": \"GELDMAAT\"\n" +
                "},\n]";
        return jsonResponse;
    }
}
