package com.example.web;

import com.example.model.AtmDetails;
import com.example.service.RetrieveAtmsService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static com.example.datafactory.AtmDetailsTestDataFactory.getAtmDetailsWithGivenCity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AtmLocatorControllerTest {

    @Mock
    private RetrieveAtmsService retrieveAtmsService;

    @InjectMocks
    private AtmLocatorController atmLocatorController;

    @Test
    public void shouldRetrieveAllTheAtmDetails() {
        //Given
        List<AtmDetails> expectedAtmDetails = Arrays.asList(getAtmDetailsWithGivenCity("city1"),
                getAtmDetailsWithGivenCity("city2"));
        when(retrieveAtmsService.getAllAtms()).thenReturn(expectedAtmDetails);

        //When
        List<AtmDetails> actualAtmDetails = atmLocatorController.getAllAtms();

        //Then
        assertEquals(2, actualAtmDetails.size());
        assertEquals(expectedAtmDetails, actualAtmDetails);

    }

    @Test
    public void shouldRetrieveAtmsByCity() {
        //Given
        List<AtmDetails> expectedAtmDetails = Arrays.asList(getAtmDetailsWithGivenCity("city1"),
                getAtmDetailsWithGivenCity("city1"));
        when(retrieveAtmsService.getAllAtmsByCity("city1")).thenReturn(expectedAtmDetails);

        //When
        List<AtmDetails> actualAtmDetails = atmLocatorController.getAllAtmsByCity("city1");

        //Then
        assertEquals(2, actualAtmDetails.size());
        assertEquals(expectedAtmDetails, actualAtmDetails);
    }

}
