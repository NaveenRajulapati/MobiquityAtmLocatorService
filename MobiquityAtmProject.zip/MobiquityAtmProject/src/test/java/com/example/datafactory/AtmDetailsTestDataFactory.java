package com.example.datafactory;

import com.example.model.Address;
import com.example.model.AtmDetails;
import com.example.model.GeoLocation;

public class AtmDetailsTestDataFactory {

    public static AtmDetails getAtmDetailsWithGivenCity(String cityName) {
        return AtmDetails.builder()
                .address(getAddress(cityName))
                .distance(100L)
                .type("test")
                .functionality("testFunctionality")
                .build();
    }

    private static Address getAddress(String cityName) {
        return Address.builder()
                .houseNumber("1234")
                .postalCode("987")
                .street("First Street")
                .geoLocation(getGeoLocation())
                .city(cityName)
                .build();
    }

    private static GeoLocation getGeoLocation() {
        return GeoLocation.builder()
                .latitude("1111")
                .longitude("2222")
                .build();
    }

}
