package com.example.service;

import com.example.model.AtmDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class RetrieveAtmsService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${mobiquity.rest.uri}")
    String restUrl;

    @Autowired
    private ObjectMapper objectMapper;

    TypeReference<List<AtmDetails>> atmDetailsTypeReference = new TypeReference<List<AtmDetails>>() {
    };

    @Cacheable(value = "atmCache", key= "#cityName")
    public List<AtmDetails> getAllAtmsByCity(String cityName) {
        List<AtmDetails> atmList = getAtmList();
        return atmList.parallelStream()
                .filter(atmDetails -> cityName.equals(atmDetails.getAddress().getCity()))
                .collect(Collectors.toList());
    }

    @Cacheable(value = "atmCache")
    public List<AtmDetails> getAllAtms() {
        return getAtmList();
    }

    private List<AtmDetails> getAtmList() {
        ResponseEntity<String> response = restTemplate.exchange(restUrl, HttpMethod.GET, null, String.class);
        String invalidCharactersString = ")]}',";
        String validJsonResponse = response.getBody().replace(invalidCharactersString, "");
        List<AtmDetails> atmDetailsList = null;
        try {
            atmDetailsList = objectMapper.readValue(validJsonResponse, atmDetailsTypeReference);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return atmDetailsList;
    }
}